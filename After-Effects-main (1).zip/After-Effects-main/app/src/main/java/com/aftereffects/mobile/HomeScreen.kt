package com.aftereffects.mobile

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/*
 * After Effects CC 2019 home screen, 1:1 with the reference screenshot (1366x729, Windows title bar removed).
 * Every number below is a reference pixel (1 dp == 1 reference px). The screen is scaled to fit the device,
 * so proportions match on any phone/tablet; the Composition panel absorbs extra width like real AE.
 */

private val AeGap = Color(0xFF1A1A1A)
private val AePanel = Color(0xFF232323)
private val AeInset = Color(0xFF1D1D1D)
private val AeHead = Color(0xFF2B2B2B)
private val AeLine = Color(0xFF3C3C3C)
private val AeTxt = Color(0xFFC9C9C9)
private val AeDim = Color(0xFF8E8E8E)
private val AeOff = Color(0xFF5A5A5A)
private val AeBlue = Color(0xFF2D8CEB)

private const val HAM = "M4 7h16M4 12h16M4 17h16"
private const val CARET = "M6 9l6 6 6-6"
private const val MAG = "M10.5 4a6.5 6.5 0 1 0 0 13 6.5 6.5 0 1 0 0-13zM15.5 15.5L21 21"
private const val LOCK = "M6 11h12v9H6zM8.5 11V8a3.5 3.5 0 0 1 6.6-1.6"
private const val TAG = "M3 12V4h8l9 9-8 8z"
private const val FLOW = "M9 3h6v5H9zM3 16h6v5H3zM15 16h6v5h-6zM12 8v4M6 16v-4h12v4"
private const val NEWI = "M5 3h10l4 4v14H5zM12 10v7M8.5 13.5h7"
private const val FOLDER = "M3 6h7l2 2h9v11H3z"
private const val COMPI = "M3 5h18v14H3zM8 16l4-7 4 7z"
private const val TRASH = "M5 7h14M9 7V4h6v3M7 7l1 13h8l1-13"
private const val GRID = "M4 4h16v16H4zM4 12h16M12 4v16"
private const val BOX = "M5 5h14v14H5z"
private const val CAM = "M3 7h4l2-2h6l2 2h4v12H3zM12 10.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 1 0 0-7z"
private const val CIRCLE = "M12 4a8 8 0 1 0 0 16 8 8 0 1 0 0-16z"
private const val COLOR = "M12 4a8 8 0 1 0 0 16 8 8 0 1 0 0-16zM12 12l6-4M12 12v8M12 12l-6-4"
private const val BRACKET = "M8 5H5v14h3M16 5h3v14h-3"
private const val AXIS = "M12 4v16M4 12h16M12 4l-2 3M12 4l2 3"
private const val SNAP = "M4 16l8-9 8 9M7 16v4M17 16v4"

private val TOOLS = listOf(
    Triple("M3 11.5L12 4l9 7.5M6 10v10h4.5v-6h3v6H18V10", 24, false),
    Triple("M7 3l11 9.5-5 .8 3 6-2.3 1-3-6L7 18z", 57, true),
    Triple("M8 11V6M11 11V4M14 11V5M17 12V8M8 11l-3-2M17 12c0 5-2 8-6 8-3 0-4-2-5.5-4.5L5 11", 81, false),
    Triple(MAG, 106, false),
    Triple("M5 12a7 7 0 1 1 2.2 5.1M5 12V6.5M5 12h5.5", 138, false),
    Triple("M3 8h12v9H3zM15 11l6-3v9l-6-3z", 163, false),
    Triple("M7 7h10v10H7zM12 2v4M12 18v4M2 12h4M18 12h4", 187, false),
    Triple("M4 6h16v12H4z", 219, false),
    Triple("M4 20l4.5-1 10-10-3.5-3.5-10 10zM13 7l3.5 3.5", 244, false),
    Triple("M5 6V4.5h14V6M12 4.5V20M9 20h6", 269, false),
    Triple("M19 4l-8 8M10.5 12.5c-3 0-4 2-4.5 4S4 19 4 19s3 1 5.5 0 3-3.5 3-5.5z", 297, false),
    Triple("M9 4h6v6l2 3H7l2-3zM6 16h12v4H6z", 325, false),
    Triple("M4 15l8-9 7 6-6 7H8zM9 20h11", 352, false),
    Triple("M13 5l6 6M6 20c0-3 2-4 4-4l-1-1 5-5 3 3-5 5-1-1c0 2-1 5-5 5z", 384, false),
    Triple("M14 4l6 6-3 1-3 3 .5 3.5-1.5 1.5-4.5-4.5-5 5-1-1 5-5L4.5 9l1.5-1.5L9.5 8l3-3z", 413, false)
)
private val ALIGN = listOf(
    "M4 3v18M8 6h12v4H8zM8 14h7v4H8z", "M12 3v18M5 6h14v4H5zM8 14h8v4H8z", "M20 3v18M4 6h12v4H4zM9 14h7v4H9z",
    "M3 4h18M6 8v12h4V8zM14 8v8h4V8z", "M3 12h18M6 5v14h4V5zM14 8v8h4V8z", "M3 20h18M6 4v12h4V4zM14 8v8h4V8z"
)
private val DIST = listOf(
    "M3 4h18M3 11h18M3 18h18M8 5v4M8 12v4", "M3 4h18M7 6h10v3H7zM7 14h10v3H7z", "M3 20h18M3 13h18M3 6h18M8 8v4",
    "M4 3v18M11 3v18M18 3v18M6 8h3M13 8h3", "M4 3v18M12 3v18M20 3v18M7 8h3M14 8h3", "M4 3v18M13 3v18M20 3v18M8 8h3M15 8h3"
)

@Composable
fun AeHomeScreen(onNewComposition: () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxSize().background(AeGap)) {
        val s = minOf(constraints.maxHeight / 706f, constraints.maxWidth / 1366f)
        CompositionLocalProvider(LocalDensity provides Density(s, 1f)) {
            Column(Modifier.fillMaxSize()) {
                MenuBar()
                ToolBar()
                Row(Modifier.fillMaxWidth().weight(1f)) {
                    ProjectPanel(Modifier.width(322.dp).fillMaxHeight())
                    Spacer(Modifier.width(3.dp))
                    CompPanel(Modifier.weight(1f).fillMaxHeight(), onNewComposition)
                    Spacer(Modifier.width(5.dp))
                    DockPanel(Modifier.width(219.dp).fillMaxHeight())
                }
                Spacer(Modifier.height(3.dp))
                RenderQueue(Modifier.fillMaxWidth().height(204.dp))
                StatusBar()
            }
        }
    }
}

@Composable
private fun Tx(s: String, c: Color = AeDim, sz: Int = 12, w: FontWeight = FontWeight.Normal, a: TextAlign = TextAlign.Start, lh: Int = sz + 4) =
    BasicText(s, style = TextStyle(color = c, fontSize = sz.sp, fontWeight = w, fontFamily = FontFamily.SansSerif, textAlign = a, lineHeight = lh.sp), softWrap = false)

@Composable
private fun At(x: Int, cy: Int, s: String, c: Color = AeDim, sz: Int = 12, w: FontWeight = FontWeight.Normal) =
    Box(Modifier.offset(x.dp, (cy - 9).dp).height(18.dp), Alignment.CenterStart) { Tx(s, c, sz, w) }

@Composable
private fun Ico(d: String, cx: Int, cy: Int, size: Int = 14, c: Color = AeDim, fill: Boolean = false) {
    val path = remember(d) { PathParser().parsePathString(d).toPath() }
    Canvas(Modifier.offset((cx - size / 2).dp, (cy - size / 2).dp).size(size.dp)) {
        scale(size.dp.toPx() / 24f, Offset.Zero) {
            drawPath(path, c, style = if (fill) Fill else Stroke(1.7f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

@Composable
private fun Bx(x: Int, y: Int, w: Int, h: Int, bg: Color, r: Int = 2, bd: Color? = null, content: @Composable BoxScope.() -> Unit = {}) {
    val sh = RoundedCornerShape(r.dp)
    var m = Modifier.offset(x.dp, y.dp).size(w.dp, h.dp).background(bg, sh)
    if (bd != null) m = m.border(1.dp, bd, sh)
    Box(m, content = content)
}

@Composable
private fun VL(x: Int, y: Int, h: Int, c: Color = AeGap) = Box(Modifier.offset(x.dp, y.dp).size(1.dp, h.dp).background(c))

@Composable
private fun HL(x: Int, y: Int, w: Int, c: Color = AeGap) = Box(Modifier.offset(x.dp, y.dp).size(w.dp, 1.dp).background(c))

@Composable
private fun Dd(x: Int, y: Int, w: Int, label: String = "", h: Int = 18) = Bx(x, y, w, h, AeHead) {
    Box(Modifier.align(Alignment.CenterStart).padding(start = 7.dp)) { Tx(label, AeOff, 11) }
    Ico(CARET, w - 9, h / 2, 9, AeOff)
}

@Composable
private fun MenuBar() = Box(Modifier.fillMaxWidth().height(21.dp).background(AePanel)) {
    listOf("File" to 7, "Edit" to 38, "Composition" to 74, "Layer" to 156, "Effect" to 198, "Animation" to 243, "View" to 312, "Window" to 351, "Help" to 408)
        .forEach { (t, x) -> At(x, 10, t, AeTxt) }
}

@Composable
private fun ToolBar() = Box(Modifier.fillMaxWidth().height(27.dp).background(AePanel)) {
    Bx(46, 2, 23, 23, Color(0xFF3B5169))
    TOOLS.forEach { (d, x, f) -> Ico(d, x, 13, 16, if (x == 24 || x == 57) AeTxt else AeDim, f) }
    VL(452, 3, 21); VL(467, 3, 21)
    Bx(472, 3, 23, 21, Color(0xFF2F4054))
    listOf(483, 507, 531).forEachIndexed { i, x -> Ico(AXIS, x, 13, 15, if (i == 0) AeBlue else AeDim) }
    VL(546, 3, 21)
    Bx(557, 7, 13, 13, AeInset, 2, AeDim); At(575, 13, "Snapping", AeTxt)
    Ico(SNAP, 639, 13, 15); Ico(BRACKET, 661, 13, 15, AeBlue)
    At(727, 13, "Default", AeBlue); Ico(HAM, 781, 13, 12, AeBlue)
    At(809, 13, "Learn", AeTxt); At(882, 13, "Standard", AeTxt); At(971, 13, "Small Screen", AeTxt)
    Box(Modifier.align(Alignment.TopEnd).size(251.dp, 27.dp)) {
        At(0, 13, "»", AeTxt, 14)
        Bx(18, 3, 24, 21, AeHead) { Ico(GRID, 12, 10, 13) }
        Bx(53, 3, 184, 19, AeInset, 3, AeLine) {
            Ico(MAG, 10, 9, 12, AeTxt)
            Box(Modifier.offset(28.dp, 0.dp).height(19.dp), Alignment.CenterStart) { Tx("Search Help", AeTxt, 12) }
        }
    }
}

@Composable
private fun ProjectPanel(m: Modifier) = Box(m.background(AePanel)) {
    At(14, 15, "Project", AeTxt); Ico(HAM, 64, 15, 12)
    Bx(8, 140, 306, 20, AeInset, 3, AeLine) { Ico(MAG, 10, 10, 12); Ico(CARET, 20, 10, 9) }
    Bx(0, 167, 321, 19, AeHead)
    At(23, 176, "Name", AeDim, 10); Ico("M7 15l5-6 5 6z", 235, 176, 11, AeBlue, true)
    VL(247, 167, 19); Ico(TAG, 259, 176, 11); VL(272, 167, 19); At(277, 176, "Comment", AeDim, 10)
    Ico(FLOW, 311, 195, 12)
    Ico(NEWI, 14, 421, 14); Ico(FOLDER, 38, 421, 14); Ico(COMPI, 63, 421, 14); Ico(FLOW, 88, 421, 14)
    Bx(103, 413, 45, 16, AeHead, 8) { Box(Modifier.align(Alignment.Center)) { Tx("16 bpc", AeTxt, 10) } }
    Ico(TRASH, 160, 421, 13)
    Bx(175, 414, 127, 14, Color(0xFF2F2F2F), 7)
}

@Composable
private fun CompPanel(m: Modifier, onNew: () -> Unit) = Box(m.background(AePanel)) {
    At(9, 15, "×", AeDim, 14); Ico(LOCK, 31, 14, 12); At(45, 15, "Composition", AeTxt); At(111, 15, "(none)", AeBlue); Ico(HAM, 157, 15, 12)
    Box(Modifier.offset(0.dp, 53.dp).fillMaxWidth().height(1.dp).background(AeGap))
    Row(Modifier.align(Alignment.TopCenter).offset(0.dp, 103.dp), horizontalArrangement = Arrangement.spacedBy(67.dp)) {
        Tile(213, "New Composition", false, onNew)
        Tile(214, "New Composition\nFrom Footage", true, onNew)
    }
    Ico(BOX, 12, 419, 12); Ico(GRID, 33, 419, 12); Ico(CAM, 56, 419, 12)
    Dd(73, 410, 57, "25%"); Ico(BOX, 144, 419, 12)
    Bx(160, 410, 24, 18, AePanel, 2, AeBlue); Ico(BRACKET, 172, 419, 12, AeBlue)
    At(190, 419, "0:00:00:00", AeOff, 11)
    Ico(CAM, 262, 419, 12); Ico(CIRCLE, 283, 419, 12); Ico(COLOR, 306, 419, 12)
    Dd(322, 410, 79, "Full"); Ico(GRID, 415, 419, 12); Ico(BOX, 436, 419, 12)
    Dd(450, 410, 102); Dd(560, 410, 62, "1 View")
    Ico(GRID, 637, 419, 12); Ico(BOX, 660, 419, 12); Ico(GRID, 679, 419, 12); Ico(CAM, 702, 419, 12); Ico(CIRCLE, 728, 419, 12)
    At(741, 419, "+0.0", AeOff, 11)
}

@Composable
private fun Tile(w: Int, label: String, footage: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(w.dp, 230.dp).background(AeInset).clickable(onClick = onClick)) {
        val iw = if (footage) 112 else 95
        Canvas(Modifier.offset(((w - iw) / 2).dp, 60.dp).size(iw.dp, 59.dp)) {
            val ln = Color(0xFF8D8D8D)
            val st = Stroke(1.3.dp.toPx())
            fun p(v: Float) = v.dp.toPx()
            val ox = if (footage) 18f else 0f
            drawRect(ln, Offset(p(ox + .5f), p(.5f)), Size(p(93f), p(58f)), style = st)
            val tri = Path().apply { moveTo(p(ox + 29f), p(39f)); lineTo(p(ox + 44f), p(13f)); lineTo(p(ox + 59f), p(39f)); close() }
            drawPath(tri, ln, style = st)
            drawCircle(ln, p(11f), Offset(p(ox + 50f), p(40f)), style = st)
            drawRect(ln, Offset(p(ox + 51f), p(16f)), Size(p(23f), p(22f)), style = st)
            if (footage) {
                drawRect(AeInset, Offset(0f, p(16f)), Size(p(36f), p(43f)))
                drawRect(ln, Offset(p(.5f), p(16.5f)), Size(p(35f), p(42f)), style = st)
                for (i in 0..3) {
                    val y = p(22f + i * 9.5f)
                    drawRect(ln, Offset(p(5f), y), Size(p(5f), p(5f)), style = st)
                    drawRect(ln, Offset(p(26f), y), Size(p(5f), p(5f)), style = st)
                }
            }
        }
        Box(Modifier.offset(0.dp, 150.dp).fillMaxWidth(), Alignment.TopCenter) {
            Tx(label, Color(0xFF9B9B9B), 12, a = TextAlign.Center, lh = 19)
        }
    }
}

@Composable
private fun DockPanel(m: Modifier) = Box(m.background(AePanel)) {
    listOf("Info" to 15, "Audio" to 45, "Preview" to 75, "Effects & Presets" to 105, "Align" to 135,
        "Libraries" to 268, "Character" to 298, "Paragraph" to 328, "Tracker" to 358).forEach { (t, y) -> At(12, y, t, AeTxt) }
    listOf(29, 59, 89, 119, 252, 282, 312, 342, 372).forEach { HL(0, it, 219) }
    Ico(HAM, 190, 135, 12)
    At(6, 161, "Align Layers to:", AeTxt, 11); Dd(92, 153, 110, "Selection", 16)
    At(6, 209, "Distribute Layers:", AeTxt, 11)
    listOf(18, 53, 88, 121, 155, 189).forEachIndexed { i, x -> Ico(ALIGN[i], x, 185, 15, AeOff); Ico(DIST[i], x, 227, 15, AeOff) }
}

@Composable
private fun RenderQueue(m: Modifier) = Box(m.background(AePanel)) {
    At(30, 14, "(none)", AeDim); At(100, 14, "×", AeDim, 13); At(119, 14, "Render Queue", AeTxt); Ico(HAM, 204, 14, 12)
    HL(102, 25, 107, Color(0xFFB4B4B4))
    Box(Modifier.padding(horizontal = 10.dp).offset(0.dp, 36.dp).fillMaxWidth().height(6.dp).background(AeGap))
    Box(Modifier.padding(start = 10.dp, end = 398.dp).offset(0.dp, 64.dp).fillMaxWidth().height(17.dp).background(AeInset))
    Ico("M9 6l6 6-6 6", 15, 72, 10); At(29, 72, "Current Render", AeTxt, 11, FontWeight.Bold)
    At(527, 72, "Elapsed:", AeTxt, 11, FontWeight.Bold); At(808, 72, "Est. Remain:", AeTxt, 11, FontWeight.Bold)
    Row(Modifier.align(Alignment.TopEnd).padding(top = 61.dp, end = 10.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        listOf("Queue in AME", "Stop", "Pause", "Render").forEach { b ->
            Box(Modifier.size(92.dp, 19.dp).background(AeHead, RoundedCornerShape(2.dp)), Alignment.Center) { Tx(b, AeOff, 11) }
        }
    }
    Box(Modifier.offset(0.dp, 91.dp).fillMaxWidth().height(17.dp).background(AeHead))
    Box(Modifier.offset(0.dp, 108.dp).fillMaxWidth().height(96.dp).background(AeInset))
    listOf("Render" to 22, "#" to 88, "." to 104, "Comp Name" to 128, "Status" to 254, "Started" to 355, "Render Time" to 485)
        .forEach { (t, x) -> At(x, 99, t, AeDim, 10) }
    Ico(TAG, 73, 99, 10)
    listOf(63, 119, 249, 350, 481, 609).forEach { VL(it, 91, 17) }
}

@Composable
private fun StatusBar() = Box(Modifier.fillMaxWidth().height(20.dp).background(AePanel)) {
    listOf("Message:" to 11, "RAM:" to 304, "Renders Started:" to 577, "Total Time Elapsed:" to 909)
        .forEach { (t, x) -> At(x, 10, t, AeDim, 11, FontWeight.Bold) }
}
